const config = {
	window: {
		width: 1000,
		height: 800,
		color: "#DEEFF5",
		font: "20px Arial",
		fontColor: "#000000",
	},

	game: {
		autoPlay: true,
	},

	player: {
		name: "Johnnie",
		lives: 1,
		level: 1,
		score: 0,
	},

	controls: {
		paddleLeft: "a",
		paddleRight: "d",
		gmaeStart: "space",
	},

	ball: {
		x: 20,
		y: 200,
		vx: 1,
		vy: 1,
		rad: 15,
		velocity: 10,
		color: "#393e46",
	},

	paddle: {
		x: 500,
		y: 650,
		vx: 35,
		vy: 35,
		width: 200,
		height: 20,
		velocity: 10,
		color: "#393e46",
	},

	brick: {
		x_offset: 50,
		y_offset: 60,
		height: 25,
		padding: 2,
		minDensity: 1,
		density: 1,
		fontColors: [
			"#445AC0",
			"#457EC4",
			"#296BBB",
			"#0E58B3",
			"#7ED3BD",
			"#76C6B2",
		],
		colors: ["#BEDFEC", "#7DBFD9", "#5CAFCF", "#3C9FC6", "#187BA2", "#146687"],
	},
};

export default config;
