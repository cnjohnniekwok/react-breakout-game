import React from "react";
import config from "../main/config";
let { window, ball, brick, player, game } = config;

const ScoreBoard = (ctx) => {
	ctx.font = window.font;
	ctx.fillStyle = window.fontColor;

	//Display player's name
	ctx.fillText(`Player: ${player.name}`, 20, window.height - 30);

	//Display player score
	ctx.fillText(`Score: ${player.score}`, 20, 30);
	//Display player level
	ctx.fillText(`Level: ${player.level}`, window.width - 100, 30);

	//Display player lives
	let ballleft = "";
	for (var i = 0; i < player.lives; i++) {
		ballleft += "❍";
	}
	ctx.fillText(ballleft, 20, window.height - 60);

	//Display current speed
	let speed = "";
	for (var j = 0; j < ball.velocity; j++) {
		speed += "➧";
	}
	if (j > 10) ctx.fillStyle = "red";
	if (j >= 20) speed += " MAX!";
	ctx.fillText(speed, 20, window.height - 80);

	//Game over when player has no more lives
	if (!player.lives) game.end = true;

	//Debug use only
	//-------------------------------------------------------------------|
	//ctx.fillText(`Density: ${brick.density}`, 300, window.height - 60);
	//-------------------------------------------------------------------|
	return <div></div>;
};

export default ScoreBoard;
