//the BallObject class
class BallObject {
	constructor(x, y, rad, color) {
		this.x = x;
		this.y = y;
		this.rad = rad;
		this.c = color;
	}

	draw(ctx) {
		ctx.beginPath();
		ctx.fillStyle = this.c;
		ctx.arc(this.x, this.y, this.rad, 0, 2 * Math.PI);
		ctx.stroke();
		ctx.fill();
	}
}

export default BallObject;
