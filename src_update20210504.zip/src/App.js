import React from "react";
import "./App.css";
import BouncingBall from "./main/index";

function App() {
	return <BouncingBall />;
}

export default App;
