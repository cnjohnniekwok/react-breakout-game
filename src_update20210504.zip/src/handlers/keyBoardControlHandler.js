import React from "react";
import useKeypress from "../util/useKeypress";
import config from "../main/config";
let { paddle, controls, window } = config;

//Listen to keyboard input and asign paddle movement
const KeyboardControl = () => {

	useKeypress(controls.paddleRight, () => {
		//Check paddle to window right edge boundary.
		if (paddle.x + paddle.width + paddle.vx <= window.width) {
			paddle.x += paddle.vx;
		}
		else{
			paddle.x = window.width - (paddle.width)
		}
	});

//Check paddle to window left edge boundary.
	useKeypress(controls.paddleLeft, () => {
		if (paddle.x - paddle.vx >= 0) {
			paddle.x -= paddle.vx;
		}
		else{
			paddle.x -= paddle.x;
		}
	});

	//React component for injection
	return <div onKeyPress={useKeypress} />;
};

export default KeyboardControl;
