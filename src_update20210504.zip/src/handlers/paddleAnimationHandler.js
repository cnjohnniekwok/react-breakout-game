import config from "../main/config";
import PaddleObject from "../components/Paddle";
let { ball, paddle } = config;

//Create the Paddle
const Paddle = (ctx, autoPlay) => {
	let animatedPaddle = new PaddleObject(
		paddle.x,
		paddle.y,
		paddle.width,
		paddle.height,
		paddle.color
	);
	animatedPaddle.draw(ctx);

	if (autoPlay) paddle.x = ball.x - paddle.width / 2;
};

export default Paddle;
