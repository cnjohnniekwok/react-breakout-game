import config from "../main/config";
let { ball, paddle, player } = config;

//Initialize or reset the game
const gameInitializeHandler = () => {
	//set initial ball position
	ball.x = paddle.x + paddle.width / 2;
	ball.y = paddle.y - paddle.height;

	player.score = 0;
	player.level = 1;
	player.lives = 5;
};

export default gameInitializeHandler;
