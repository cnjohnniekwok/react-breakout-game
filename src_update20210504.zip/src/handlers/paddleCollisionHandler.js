import config from "../main/config";
let { ball, paddle } = config;

//Handles the ball and paddle collision
const paddleCollisionHandler = () => {
	if (
		ball.x + ball.rad + ball.vx >= paddle.x &&
		ball.x - ball.rad - ball.vx <= paddle.x + paddle.width &&
		ball.y - ball.rad - ball.vy <= paddle.y + paddle.height &&
		ball.y + ball.rad + ball.vy >= paddle.y
	) {
		//if some how the ball stuck inside the paddle dimension, change X direction (repel it!)
		if (
			ball.y + ball.rad + ball.vy >= paddle.y + paddle.height &&
			ball.x + ball.rad + ball.vx >= paddle.x &&
			ball.x - ball.rad - ball.vx <= paddle.x + paddle.width
		) {
			ball.vx = -ball.vx;
		} else {
			//otherwise turn the ball away.
			ball.vy = -ball.vy;
		}
	}
};
export default paddleCollisionHandler;
