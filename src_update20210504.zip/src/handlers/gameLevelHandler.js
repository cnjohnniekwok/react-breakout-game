import BricksArray from "../handlers/bricksCreationHandler";
import initGame from "../handlers/gameInitializeHandler";
import config from "../main/config";
let { player, ball, brick, paddle } = config;

let bricksArray = BricksArray(3, 1);
const gameLevelHandler = (ctx) => {
	let brickGone = 0;
	for (var i = 0; i <= bricksArray.length - 1; i++) {
		let eachBrick = bricksArray[i];

		//Count bricks being hit
		if (eachBrick.gone) brickGone++;

		//No more lives?
		if (player.lives <= 0) {
			alert(`You've drop all the balls... D:`);
			initGame();
			player.level = 0;
			brickGone = bricksArray.length;
		}

		//Level up!
		if (brickGone === bricksArray.length) {
			//Set initial ball position
			ball.x = paddle.x + paddle.width / 2;
			ball.y = paddle.y - paddle.height - ball.rad;

			//Increment player's level
			player.level++;
			if (player.level > 10) {
				setTimeout(function () {
					alert(`OK, you win :) You scored (${player.score})!`);
					initGame();
				}, 500);
			}

			//Level Generation
			let numBricks = 4;
			let numRows = 1;
			if (player.level >= 3) {
				//Density will increase after level 3
				if (brick.density < 6) brick.density++;

				//Paddle width will decrease after level 5
				if (player.level > 5) {
					if (paddle.width > 100) paddle.width -= 30;
				}

				numBricks = player.level;
				numRows = player.level - 1;
			}

			//Create new level bricks array
			bricksArray = BricksArray(numBricks, numRows);

			break;
		}

		//Draw bricks
		eachBrick.draw(ctx);
	}

	return bricksArray;
};

export default gameLevelHandler;
