import config from "../main/config";
let { ball, paddle, window, player } = config;

//Handle ball and window windowCollision
const windowCollisionHandler = () => {
	//check window top edge
	if (ball.y + ball.vy * ball.velocity - ball.rad <= 0) {
		ball.vy = -ball.vy;
		//check window left and right edge
	} else if (
		ball.x + ball.vx * ball.velocity + ball.rad >= window.width ||
		ball.x + ball.vx * ball.velocity - ball.rad <= 0
	) {
		ball.vx = -ball.vx;
		//check window bottom edge (Game over boundary)
	} else if (
		ball.y + ball.vy * ball.velocity + ball.rad >=
		window.height + 300
	) {
		player.lives -= 1;

		ball.x = paddle.x + paddle.width / 2;
		ball.y = paddle.y - paddle.height - ball.rad;
	}
};

export default windowCollisionHandler;
