import React from "react";
import Canvas from "./Canvas";

function BouncingBall() {
	return (
		<div>
			<Canvas />
		</div>
	);
}

export default BouncingBall;
