import React from "react";
import config from "../main/config";
let { window, brick, ball, paddle, player, game } = config;

/*
 *	@desc	display game level status
 *  @param ctx - Canvas context, for graphics rendering
 */
const ScoreBoard = (ctx) => {
	ctx.font = window.font;
	ctx.fillStyle = window.fontColor;

	//Display player score
	ctx.fillText(`Score: ${player.score}`, 20, 40);
	//Display player level
	ctx.fillText(`Level: ${player.level}`, window.width - 120, 40);

	//Display player lives
	let ballleft = "";
	for (var i = 0; i < player.lives; i++) {
		ballleft += "❍";
	}
	ctx.fillText(ballleft, 20, window.height - 30);

	//Display current speed
	let speed = "";
	for (var j = 0; j < ball.velocity; j++) {
		speed += "➧";
	}
	if (j > 10) ctx.fillStyle = "red";
	if (j >= 20) speed += " MAX!";
	ctx.fillText(speed, 20, window.height - 50);

	//Game over when player has no more lives
	if (!player.lives) game.end = true;

	//Debug use only
	//-------------------------------------------------------------------|
	if (game.debug) {
		ctx.font = "12px Arial";
		ctx.fillStyle = "red";
		ctx.fillText(
			`AutoPlay: (${game.autoPlay}) | Ball Vector: (${ball.vx},${ball.vy}) | Ball Coordinate: (${ball.x},${ball.y})  | Ball Velocity: (${ball.velocity}) | Paddle Width: (${paddle.width}) | Level Max Density: (${brick.density})`,
			300,
			window.height - 10
		);

		ctx.fillStyle = "blue";
		ctx.fillText(
			`Speed:[ + ],[ - ] | AutoPlay:[U] | Call back ball:[C] `,
			300,
			window.height - 25
		);
	}
	//-------------------------------------------------------------------|
	return <div></div>;
};

export default ScoreBoard;
