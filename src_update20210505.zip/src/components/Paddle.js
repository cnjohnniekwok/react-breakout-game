import config from "../main/config";
let { game } = config;
/*
 *	 @desc  PaddleObject class
 *   @param x - paddle x position
 *   @param y - paddle y position
 *   @param width - paddle width
 *   @param height - paddle heigth
 *   @param density - paddle color
 */
class PaddleObject {
	constructor(x, y, width, height, color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}

	draw(ctx) {
		ctx.beginPath();
		ctx.fillStyle = this.color;
		ctx.rect(this.x, this.y, this.width, this.height);
		ctx.stroke();
		ctx.fill();

		//debug only
		//------------------------------------------------|
		if (game.debug) {
			ctx.font = "10px Arial";
			ctx.fillStyle = "red";
			ctx.fillText(`xy(${this.x},${this.y})`, this.x, this.y);
			ctx.fillText(
				`x+w(${this.x + this.width},${this.y})`,
				this.x + this.width,
				this.y
			);
			ctx.fillText(
				`y+h(${this.x},${this.y + this.height})`,
				this.x,
				this.y + this.height
			);
			ctx.fillText(
				`|(${this.x + Math.floor(this.width / 15)})`,
				this.x + this.width / 15,
				this.y - this.height
			);
			ctx.fillText(
				`|(${this.x + Math.floor(this.width - this.width / 15)})`,
				this.x + this.width - this.width / 15,
				this.y - this.height
			);
		}
	}
}

export default PaddleObject;
