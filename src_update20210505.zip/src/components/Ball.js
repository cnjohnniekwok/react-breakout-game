import config from "../main/config";
let { game } = config;
/*
 *	 @desc  BallObject class
 *   @param x - ball x position
 *   @param y - ball y position
 *   @param rad - ball radius
 *   @param color - ball color
 */
class BallObject {
	constructor(x, y, rad, color) {
		this.x = x;
		this.y = y;
		this.rad = rad;
		this.c = color;
	}

	draw(ctx) {
		ctx.beginPath();
		ctx.fillStyle = this.c;
		ctx.arc(this.x, this.y, this.rad, 0, 2 * Math.PI);
		ctx.stroke();
		ctx.fill();

		//debug only
		//------------------------------------------------|
		if (game.debug) {
			ctx.font = "10px Arial";
			ctx.fillStyle = "red";
			ctx.fillText(`xy`, this.x, this.y);
			ctx.fillText(`x+r`, this.x + this.rad, this.y);
			ctx.fillText(`x-r`, this.x - this.rad, this.y);
			ctx.fillText(`y+r`, this.x, this.y + this.rad);
			ctx.fillText(`y-r`, this.x, this.y - this.rad);
		}
	}
}

export default BallObject;
