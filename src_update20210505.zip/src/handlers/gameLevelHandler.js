import BricksArray from "../handlers/bricksCreationHandler";
import config from "../main/config";
let { game, window, player, ball, brick, paddle } = config;

//Level Generation

let bricksArray = BricksArray(brick.numBricks, brick.numRows); //Fist level
/*
 *	 @desc  Create/Generate game level elements, checks for end game, handle level transitions
 *   @param ctx - Canvas context, for graphics rendering
 */
const gameLevelHandler = (ctx) => {
	let brickGone = 0;
	for (var i = 0; i <= bricksArray.length - 1; i++) {
		let eachBrick = bricksArray[i];

		//Count bricks being hit
		if (eachBrick.gone) brickGone++;

		//No more lives?
		if (player.lives <= 0) break;

		//Level up!
		if (brickGone === bricksArray.length) break;

		//Draw bricks
		eachBrick.y += brick.dy;
		eachBrick.x += brick.dx;
		if (eachBrick.y >= window.height / 2) brick.dy = -brick.dy;
		if (eachBrick.y <= brick.y_offset) brick.dy = -brick.dy;
		if (eachBrick.x + eachBrick.w >= window.width) brick.dx = -brick.dx;
		if (eachBrick.x <= 0) brick.dx = -brick.dx;

		eachBrick.draw(ctx);
	}

	//Handles new level or end game
	if (brickGone === bricksArray.length || player.lives <= 0) {
		//Set initial ball position
		ball.x = paddle.x + paddle.width / 2;
		ball.y = paddle.y - paddle.height - ball.rad;

		// Exhausted all lives and LOSE.
		if (player.lives <= 0) {
			game.over = true;
			bricksArray = BricksArray(3, 1);
			ctx.font = window.font;
			ctx.fillStyle = window.fontColor;

			ctx.fillText(
				`You've drop all the balls... D: You scored (${player.score})!`,
				window.width / 2 - 250,
				window.height / 2
			);

			ctx.font = "18px Arial";
			ctx.fillStyle = "blue";
			ctx.fillText(
				`Press [I] to start again!`,
				window.width / 2 - 100,
				window.height / 2 + 30
			);
		}

		// Reaches the highest level and WON. TODO, why new game after win start on level2?
		if (player.level >= game.maxLevels) {
			game.over = true;
			ctx.font = window.font;
			ctx.fillStyle = window.fontColor;

			ctx.fillText(
				`OK, you win :) You scored (${player.score})!`,
				window.width / 2 - 200,
				window.height / 2
			);

			ctx.font = "18px Arial";
			ctx.fillStyle = "blue";
			ctx.fillText(
				`Press [I] to start again! | [U] to auto play | [D] for debug mode`,
				window.width / 2 - 250,
				window.height / 2 + 30
			);
		}
		if (!game.over) {
			//Increment player's level
			player.level += 1;
			game.over = false;

			//Density will increase after level 3
			if (brick.density < brick.maxDensity) brick.density += 1;

			//Paddle width will decrease after level 5
			if (player.level > 5) {
				if (paddle.width > 100) paddle.width -= 30;
			}

			brick.numBricks = player.level + 1;
			brick.numRows = player.level >= 3 ? player.level - 1 : 2;

			//Create new level bricks array
			bricksArray = BricksArray(brick.numBricks, brick.numRows);
		}
	}
	return bricksArray;
};

export default gameLevelHandler;
