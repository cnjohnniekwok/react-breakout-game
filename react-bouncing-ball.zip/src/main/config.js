const config = {
	window: {
		width: 1000,
		height: 800,
		color: "#00adb5",
	},

	game: {
		start: false,
		end: true,
	},

	player: {
		name: "Johnnie",
		lives: 5,
		score: 0,
		level: 1,
	},

	controls: {
		paddleLeft: "a",
		paddleRight: "d",
		gmaeStart: "space",
	},

	ball: {
		x: 20,
		y: 200,
		vx: 1,
		vy: 1,
		rad: 15,
		velocity: 3,
	},

	paddle: {
		x: 500,
		y: 700,
		vx: 35,
		vy: 35,
		width: 200,
		height: 20,
		velocity: 10,
		color: "#393e46",
	},

	brick: {
		x_offset: 15,
		y_offset: 50,
		width: 150,
		height: 20,
		padding: 6,
		minDensity: 6,
		density: 1,
		colors: ["#1cb6bd", "#55c8cd", "#8ddade", "#aae3e6", "#e2f5f6", "#ffffff"],
	},
};

export default config;
