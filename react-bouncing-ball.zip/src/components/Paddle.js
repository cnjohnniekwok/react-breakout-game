class PaddleObject {
	constructor(x, y, length, width, color) {
		this.x = x;
		this.y = y;
		this.length = length;
		this.width = width;
		this.color = color;
	}

	draw(ctx) {
		ctx.beginPath();
		ctx.fillStyle = this.color;
		ctx.rect(this.x, this.y, this.length, this.width);
		ctx.stroke();
		ctx.fill();
	}
}

export default PaddleObject;
