class BrickObject {
	constructor(x, y, width, height, density, colors) {
		this.x = x - width;
		this.y = y;
		this.w = width;
		this.h = height;
		this.d = density;
		this.c = colors;
		this.gone = false;
	}

	draw(ctx) {
		if (!this.gone) {
			ctx.beginPath();
			ctx.rect(this.x, this.y, this.w, this.h);
			if (this.d > 5) {
				let gradient = ctx.createLinearGradient(this.x, this.y, this.w, this.h);
				gradient.addColorStop(0, this.c[0]);
				gradient.addColorStop(1, this.c[this.c.length - 1]);
				ctx.fillStyle = gradient;
				ctx.fillRect(this.x, this.y, this.w, this.h);
			} else {
				ctx.fillStyle = this.c[this.d];
				ctx.fillRect(this.x, this.y, this.w, this.h);
			}
			ctx.strokeStyle = "#00000";
			ctx.stroke();

			ctx.font = "20px Verdana";
			let bar = "";
			for (var i = 1; i < this.d; i++) bar += "|";
			ctx.fillText(bar, this.x, this.y + this.h);
		}
	}

	setHit() {
		if (this.d <= 1) {
			this.gone = true;
		}
		this.d -= 1;
	}
}

export default BrickObject;
