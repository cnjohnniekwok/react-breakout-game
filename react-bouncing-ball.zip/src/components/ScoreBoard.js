import React from "react";
import config from "../main/config";

let { window, player, game } = config;

const ScoreBoard = (ctx) => {
	ctx.font = "20px Arial";
	ctx.fillStyle = "white";
	ctx.fillText(`Player: ${player.name}`, 20, window.height - 30);

	ctx.font = "20px Arial";
	ctx.fillStyle = "red";
	let gap = 0;
	for (var i = 0; i < player.lives; i++) {
		ctx.fillText("❍", 20 + gap, window.height - 60);
		gap += 15;
	}

	if (!player.lives) game.end = true;

	ctx.font = "20px Arial";
	ctx.fillStyle = "white";
	ctx.fillText(`Score: ${player.score}`, 20, 30);

	return <div></div>;
};

export default ScoreBoard;
