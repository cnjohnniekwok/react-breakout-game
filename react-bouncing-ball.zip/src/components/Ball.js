class BallObject {
	constructor(x, y, rad) {
		this.x = x;
		this.y = y;
		this.rad = rad;
	}

	draw(ctx) {
		ctx.beginPath();
		ctx.fillStyle = "#393e46";
		ctx.arc(this.x, this.y, this.rad, 0, 2 * Math.PI);
		ctx.stroke();
		ctx.fill();
	}
}

export default BallObject;
