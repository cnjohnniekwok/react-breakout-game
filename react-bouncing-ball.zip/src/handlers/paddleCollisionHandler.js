import config from "../main/config";
let { ball, paddle } = config;

const paddleCollisionHandler = () => {
	if (
		ball.x + ball.rad + ball.vx >= paddle.x &&
		ball.x - ball.rad - ball.vx <= paddle.x + paddle.width &&
		ball.y - ball.rad - ball.vy <= paddle.y + paddle.height &&
		ball.y + ball.rad + ball.vy >= paddle.y
	) {
		if (
			ball.y + ball.rad + ball.vy >= paddle.y + paddle.height &&
			ball.x + ball.rad + ball.vx >= paddle.x &&
			ball.x - ball.rad - ball.vx <= paddle.x + paddle.width
		) {
			ball.vx = -ball.vx;
		} else {
			ball.vy = -ball.vy;
		}
	}
};
export default paddleCollisionHandler;
