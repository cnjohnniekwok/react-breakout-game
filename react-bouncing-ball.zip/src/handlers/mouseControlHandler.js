import config from "../main/config";
let { paddle, window } = config;

const mouseControl = (e) => {
	paddle.x = e.clientX - paddle.width / 2;
	if (paddle.x + paddle.width + paddle.vx > window.width) {
		paddle.x = window.width - paddle.width;
	}
	if (paddle.x - paddle.vx < 0) {
		paddle.x = 0;
	}
};

export default mouseControl;
