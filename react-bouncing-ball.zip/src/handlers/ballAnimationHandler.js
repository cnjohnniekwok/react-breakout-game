import config from "../main/config";
import BallObject from "../components/Ball";
let { ball } = config;

const Ball = (ctx) => {
	let animatedBall = new BallObject(ball.x, ball.y, ball.rad);
	animatedBall.draw(ctx);
	//console.log(`${ball.x} ${ball.y} ${ball.velocity}`);
	ball.x += ball.vx * ball.velocity;
	ball.y += ball.vy * ball.velocity;
};

export default Ball;
