import config from "../main/config";
import BrickObject from "../components/Brick";
let { brick, window } = config;

const BricksArray = (numBricks, numRows) => {
	let bricksArray = [];
	let bricksIniPlacementX = brick.x_offset + brick.width;
	let bricksIniPlacementY = brick.y_offset;

	let mindensity = brick.minDensity;
	if (brick.density < 1) brick.density = 1;

	brick.width = Math.floor(
		(window.width - brick.x_offset * 2 - brick.padding * numBricks) / numBricks
	);

	for (let i = 0; i < numRows; i++) {
		for (let j = 0; j < numBricks; j++) {
			let newBrick = new BrickObject(
				bricksIniPlacementX + (brick.width + brick.padding) * j,
				bricksIniPlacementY + (brick.height + brick.padding) * i,
				brick.width,
				brick.height,
				Math.floor(Math.random() * (brick.density - mindensity) + mindensity),
				brick.colors
			);
			bricksArray.push(newBrick);
		}
	}

	return bricksArray;
};

export default BricksArray;
