import React from "react";
import useKeypress from "../util/useKeypress";
import config from "../main/config";
let { paddle, controls, window } = config;

const KeyboardControl = () => {
	//If keypress = "A"
	useKeypress(controls.paddleRight, () => {
		if (paddle.x + paddle.length + paddle.vx <= window.width) {
			paddle.x += paddle.vx;
		}
	});

	//If keypress = "D"
	useKeypress(controls.paddleLeft, () => {
		if (paddle.x - paddle.vx >= 0) {
			paddle.x -= paddle.vx;
		}
	});

	return <div onKeyPress={useKeypress} />;
};

export default KeyboardControl;
