import config from "../main/config";
let { ball, paddle, window, player } = config;

const windowCollisionHandler = () => {
	if (ball.y - ball.rad <= 0) {
		ball.vy = -ball.vy;
	} else if (ball.x + ball.rad >= window.width || ball.x - ball.rad <= 0) {
		ball.vx = -ball.vx;
	} else if (ball.y + ball.rad >= window.height + 300) {
		player.lives -= 1;

		ball.x = paddle.x + paddle.width / 2;
		ball.y = paddle.y - paddle.height - ball.rad;
	}
};

export default windowCollisionHandler;
