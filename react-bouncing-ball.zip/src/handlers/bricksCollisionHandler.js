import config from "../main/config";
let { ball, player } = config;

const bricksCollisionHandler = (bricksArray) => {
	for (let i = 0; i <= bricksArray.length - 1; i++) {
		let checkBrick = bricksArray[i];

		if (!checkBrick.gone) {
			if (
				ball.x + ball.rad >= checkBrick.x &&
				ball.x - ball.rad <= checkBrick.x + checkBrick.w &&
				ball.y - ball.rad <= checkBrick.y + checkBrick.h &&
				ball.y + ball.rad >= checkBrick.y
			) {
				ball.vy = -ball.vy;
				checkBrick.setHit();
				player.score += 10;
			}
		}
	}
};

export default bricksCollisionHandler;
