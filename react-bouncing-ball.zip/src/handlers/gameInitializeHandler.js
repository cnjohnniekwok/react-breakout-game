import config from "../main/config";

let { ball, paddle, player } = config;

const gameInitializeHandler = () => {
	//set initial ball position
	ball.x = paddle.x + paddle.width / 2;
	ball.y = paddle.y - paddle.height - ball.rad;

	player.score = 0;
	player.lives = 5;
};

export default gameInitializeHandler;
