import config from "../main/config";
import PaddleObject from "../components/Paddle";
let { paddle } = config;

const Paddle = (ctx) => {
	let animatedPaddle = new PaddleObject(
		paddle.x,
		paddle.y,
		paddle.width,
		paddle.height,
		paddle.color
	);
	animatedPaddle.draw(ctx);
};

export default Paddle;
