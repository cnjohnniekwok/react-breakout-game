import { useEffect } from "react";

export default function useKeypress(key, action) {
	useEffect(() => {
		// check onKeydown event key
		function onKeydown(e) {
			if (e.key === key) action();
		}
		// register event listener
		window.addEventListener("keydown", onKeydown);
		// unregister event listener
		return () => window.removeEventListener("keydown", onKeydown);
	});
}
